from django.conf.urls import url
from firstpage import views

urlpatterns = [
  url(r'^$', views.HomePageView.as_view()),
  url(r'^about/$', views.AboutPageView.as_view()),
]
 #url(r'^admin/', admin.site.urls),
 #url(r'^', include('howdy.urls')),
